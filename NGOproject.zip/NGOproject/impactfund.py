# all the libraries used in the code 
import os 
import json
import numpy as np
import winsound
from datetime import datetime
import matplotlib.pyplot as plt


# all the files 
files = [
    "requests.json",          # Stores pending orphanage requests
    "donations.json",         # Stores all donation history
    "donors.json",            # Stores donor usernames and passwords
    "orphanages.json",        # Stores orphanage names and passwords
    "fulfilled_requests.json" # Stores fulfilled requests
]

def createfiles(file):
    for file in files:
        if not os.path.exists(file):
            with open(file, 'w') as f:
                if file=="funds.json":
                    json.dump({}, f)
                else:
                    json.dump([], f)
createfiles(files)

if not os.path.exists("funds.json"):
    with open("funds.json", "w") as f:
        json.dump({"health": 0, "education": 0, "shelter": 0, "general": 0}, f)


# all the functions used
def beep():
    winsound.Beep(1000,500)

def next():
    input("\n Press Enter to continue...")

def savefile(file_path, data):
    with open(file_path, "w") as f:
        json.dump(data, f)

def loadfile(file_path):
    try:
        with open(file_path, "r") as f:
            data = json.load(f)
            return data
    except:
        savefile(file_path, [])
        return []
    
def loadfunds():
    with open("funds.json", "r") as f:
        return json.load(f)  

def savefunds(funds):
    with open("funds.json", "w") as f:
        json.dump(funds, f)

def rightrequests(requests):
    required_keys = ["username", "type", "amount", "statement", "requested_at"]
    return [r for r in requests if all(k in r for k in required_keys)]


# use of class for donation
class CardValidator:
    def __init__(self):
        pass  
    
    def payment_process(self, card_number, pin, cvv, amount):
        if len(card_number) != 16 or not card_number.isdigit():
            print("Card number must be 16 digits")
            return False
        if len(pin) != 4 or not pin.isdigit():
            print("PIN must be 4 digits")
            return False
        if len(cvv) != 3 or not cvv.isdigit():
            print("CVV must be 3 digits")
            return False
        print(f"Payment of Rs. {amount} successful by card number ************{card_number[-4:]}")
        return True

def handle_request(index, pending_requests, fulfilled_requests):
    funds = loadfunds() 
    req = pending_requests.pop(index)
    amount_needed = float(req.get("amount", 0))
    if "type" in req:
        cause = req["type"].lower()
    else:
        cause = "general" 
    if cause not in funds:
        cause = "general"
    if amount_needed > (funds[cause] + funds["general"]):
        print("Not enough funds to fulfill this request!")
        pending_requests.insert(index, req)
        next()  
        return
    if amount_needed <= funds[cause]:
        funds[cause] -= amount_needed
    else:
        amount_needed -= funds[cause]
        funds[cause] = 0
        funds["general"] -= amount_needed
    req["fulfilled_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    fulfilled_requests.append(req)
    savefunds(funds)
    savefile("requests.json", pending_requests)
    savefile("fulfilled_requests.json", fulfilled_requests)

    print("Request fulfilled successfully!")
    next()  


# WORKER PORTAL

WORKER_ID = "worker1"
WORKER_PASSWORD = "pass123"

def worker_portal():
    os.system("cls")
    print("\n--- WORKER LOGIN ---")
    id = input("Worker ID: ")
    password= input("Password: ")

    if id != WORKER_ID or password != WORKER_PASSWORD:
        print("\033[91mIncorrect Credentials!\033[0m")
        beep()
        next()
        return

    while True:
        os.system("cls")
        donations = loadfile("donations.json")
        a = loadfile("requests.json")
        pending_requests = rightrequests(a)
        b = loadfile("fulfilled_requests.json")
        fulfilled_requests = rightrequests(b)
        funds = loadfunds()

        print("\n--- WORKER DASHBOARD ---")
        print("1. Donation Records")
        print("2. Checklist of Requests")
        print("3. Visualize Data")
        print("4. Logout")
        choice = input("Enter choice: ")

        # 1. Donation Records
        if choice == "1":
            os.system("cls")
            print("\n--- DONATION RECORDS ---")
            print("1. View Table of Donations")
            print("2. View Summary of Available Funds")
            choice1_1= input("Enter choice: ")

            if  choice1_1== "1":
                # code for the table
                if len(donations) > 0:
                    columns = ["Username", "Amount", "Cause", "Time"]
                    data=[]
                    for d in donations:
                        row=[d.get('username','?'), d.get('amount',0),d.get('cause','general'), d.get('time','?')]
                        data.append(row) 
                    plt.figure(figsize=(6, len(data)*0.5 + 1))  
                    plt.axis("off")
                    table = plt.table(
                        cellText=data,
                        colLabels=columns,
                        cellLoc="center",
                        colLoc="center",
                        loc="center"
                    )
                    table.scale(1, 1.5) 
                    plt.show()
                else:
                    print("No donations yet.")
                next()
                break

            elif choice1_1 == "2":
                print("\n--- Available Funds ---")
                print("Total Funds:", sum(funds.values()))
                for key in funds:
                    print(f"{key.capitalize()}: {funds[key]}")
                next()
            else:
                print("\033[91m Invalid choice! \033[0m")
                beep()
                next()

        # 2 Checklist of Requests
        elif choice == "2":
            os.system("cls")
            print("\n--- REQUEST CHECKLIST ---")
            if pending_requests:
                i = 1 
                for r in pending_requests:
                    print(f"{i}. {r.get('username','?')} | {r.get('type','?')} | "
                        f"{r.get('amount','?')} | {r.get('statement','?')}")
                    i += 1 

                fulfill = input("\nEnter request number to fulfill (or press Enter to skip): ")
                if fulfill.isdigit():
                    idx = int(fulfill) - 1
                    if 0 <= idx < len(pending_requests):
                        handle_request(idx, pending_requests, fulfilled_requests)
                    else:
                        print("\033[91mInvalid number!\033[0m")
                        beep()
                        next()
            else:
                print("No pending requests.")
                next()

        #3 visualization/graphs
        elif choice == "3":
            os.system("cls")
            all_requests = pending_requests + fulfilled_requests
            print("\n--- VISUALIZATIONS ---")
            print("1. Fund Allocation Pie Chart")
            print("2. Donations Over Time")
            print("3. Requests per Orphanage Bar Chart")
            graph_choice = input("Choose option (1/2/3): ")

            if graph_choice == "1":
                labels = list(funds.keys())
                values = list(funds.values())
                colors = ["#00E1CF", "#124736", "#BFE9E8", "#42EA9C"]
                plt.pie(values, labels=labels, autopct='%1.1f%%', colors=colors)
                plt.title("Fund Allocation")
                plt.show()

            elif graph_choice == "2":
                if donations:
                    sorted_don = sorted(donations, key=lambda x: x.get("time",""))
                    times = [d.get("time","?") for d in sorted_don]
                    amounts = [d.get("amount",0) for d in sorted_don]
                    plt.plot(times, amounts, marker='o', color="#716A9F")
                    plt.xticks(rotation=45)
                    plt.title("Donations Over Time")
                    plt.tight_layout()
                    plt.show()
                else:
                    print("No donations yet.")

            elif graph_choice == "3":
                orphanages = list({r.get("username","Unknown") for r in all_requests})
                pending_counts = [sum(1 for r in pending_requests if r.get("username")==o) for o in orphanages]
                fulfilled_counts = [sum(1 for r in fulfilled_requests if r.get("username")==o) for o in orphanages]

                x = np.arange(len(orphanages))
                width = 0.35
                fig, ax = plt.subplots()
                ax.bar(x - width/2, pending_counts, width, label='Pending', color="#EA619F")
                ax.bar(x + width/2, fulfilled_counts, width, label='Fulfilled', color='#EDB5DC')
                ax.set_xlabel('Orphanages')
                ax.set_ylabel('Number of Requests')
                ax.set_title('Requests per Orphanage (Pending vs Fulfilled)')
                ax.set_xticks(x)
                ax.set_xticklabels(orphanages, rotation=45)
                ax.legend()
                plt.tight_layout()
                plt.show()
            next()

        # 4. Logout
        elif choice == "4":
            print("\033[92m Logged out successfully!\033[0m")
            next()
            break

        else:
            print("\033[91m Invalid choice!\033[0m")
            beep()


# DONOR login and signup  
def donor_signup_login():
    while True:
        os.system("cls")
        donors = loadfile("donors.json")
        print("\n--- DONOR PORTAL ---")
        print("1. Login")
        print("2. Signup")
        print("3. Back to Main Menu")
        c = input("Enter choice: ")

        if c == "1":
            donor_name = input("Username: ")
            donor_pass = input("Password: ")
            donor = None
            for d in donors:
                if d["username"] == donor_name and d["password"] == donor_pass:
                    donor = d
                    break
            if donor:
                print(f"\033[92mWelcome, {donor_name}!\033[0m")
                donor_dashboard(donor)
            else:
                print("\033[91mIncorrect login. Try again.\033[0m")
                beep()
                next()

        elif c == "2":
            donor_name = input("Enter username: ")
            exists = any(d["username"] == donor_name for d in donors)
            if exists:
                print("\033[91mUsername already exists!\033[0m")
                beep()
                next()
                continue
            donor_pass = input("Choose password: ")
            donor = {"username": donor_name, "password": donor_pass}
            donors.append(donor)
            savefile("donors.json", donors)
            print("\033[92mSignup successful!\033[0m")
            next()
            (donor)

        elif c == "3":
            break
        else:
            print("\033[91mInvalid choice!\033[0m")
            beep()
            next()

# DONOR PORTAL
def donor_dashboard(donor):
    while (1):
        os.system("cls")
        donations = loadfile("donations.json")
        funds = loadfunds()

        print(f"\n--- Welcome {donor['username']} ---")
        print("1. View My Donations")
        print("2. Donate")
        print("3. Logout")
        choice = input("Enter choice: ")

        if choice == "1":
            # Show donations by this donor
            my = [d for d in donations if d["username"] == donor["username"]]
            if my:
                for d in my:
                    print(f"Rs. {d['amount']} | {d['cause']} | {d['time']}")
            else:
                print("No donations yet.")
            next()

        elif choice == "2":
            # Donate
            try:
                amount = float(input("Enter amount: Rs. "))
                if amount <= 0:
                    print("\033[91mAmount must be positive!\033[0m")
                    beep()
                    next()
                    continue
            except:
                print("\033[91mInvalid amount!\033[0m")
                beep()
                next()
                continue

            cause = input("Cause (health/education/shelter/general): ").lower()
            if cause not in ["health", "education", "shelter", "general"]:
                cause = "general"

            # Credit card payment
            print("\n--- Credit Card Payment ---")
            
            while (1):
                card_number = input("Enter 16-digit card number: ").replace(" ", "").replace("-", "")
                if len(card_number) == 16:
                    break
                else:
                    print(f"Error: You entered {len(card_number)} characters. Please try again.")
          
            pin = input("Enter 4-digit PIN: ")
            cvv = input("Enter 3-digit CVV: ")

            # Validate card
            validator = CardValidator()
            valid = validator.payment_process(card_number, pin, cvv, amount)
            if not valid:
                print("\033[91mPayment failed!\033[0m")
                beep()
                next()
                continue

            # Save donation
            donations.append({
                "username": donor["username"],
                "amount": amount,
                "cause": cause,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "card_last4": card_number[-4:]
            })
            savefile("donations.json", donations)

            # Update funds
            funds[cause] += amount
            savefunds(funds)

            print(f"\033[92m✓ Donation of Rs. {amount} successful!\033[0m")
            next()

        elif choice == "3":
            print("\033[92mLogged out successfully!\033[0m")
            next()
            break

        else:
            print("\033[91mInvalid choice!\033[0m")
            beep()
            next()
def orphanage_signup_login():
    while (1):
        os.system("cls")
        orphanages = loadfile("orphanages.json")
        print("\n--- ORPHANAGE PORTAL ---")
        print("1. Login")
        print("2. Signup")
        print("3. Back to Main Menu")
        c = input("Enter choice: ")

        if c == "1":
            orph_name = input("Username: ")
            orph_pass = input("Password: ")
            orphanage = None
            for o in orphanages:
                if o["username"] == orph_name and o["password"] == orph_pass:
                    orphanage = o
                    break
            if orphanage:
                print(f"\033[92mWelcome, {orph_name}!\033[0m")
                orphanage_dashboard()
            else:
                print("\033[91mIncorrect login. Try again.\033[0m")
                beep()
                next()

        elif c == "2":
            reg_pass = input("Enter Registration Password: ")
            if reg_pass != "admin123":
                print("\033[91mIncorrect Registration Password!\033[0m")
                beep()
                next()
                continue
            orph_name = input("Enter username: ")
            exists = any(o["username"] == orph_name for o in orphanages)
            if exists:
                print("\033[91mUsername already exists!\033[0m")
                beep()
                next()
                continue
            orph_pass = input("Choose password: ")
            orphanage = {"username": orph_name, "password": orph_pass}
            orphanages.append(orphanage)
            savefile("orphanages.json", orphanages)
            print("\033[92mSignup successful!\033[0m")
            next()
            (orphanage)

        elif c == "3":
            break
        else:
            print("\033[91mInvalid choice!\033[0m")
            beep()
            next()
#orphanage portal
        def orphanage_dashboard():
            while True:
                os.system("cls")
                all_requests = loadfile("requests.json")
                fulfilled_requests = loadfile("fulfilled_requests.json")

                print(f"\n--- Welcome {orph_name} ---")
                print("1. Make Request")
                print("2. View My Requests")
                print("3. View Fulfilled Requests")
                print("4. Logout")
                choice = input("Enter choice: ")

                if choice == "1":
                    cause = input("Cause (health/education/shelter/general): ").lower()
                    if cause not in ["health", "education", "shelter", "general"]:
                        cause = "general"

                    try:
                        amount = float(input("Amount needed: "))
                    except:
                        print("\033[91mInvalid amount!\033[0m")
                        #beep()
                        next()
                        continue

                    statement = input("Explain the need: ")

                    all_requests.append({
                        "username": orph_name,
                        "type": cause,
                        "amount": amount,
                        "statement": statement,
                        "requested_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    })

                    savefile("requests.json", all_requests)
                    print("\033[92mRequest submitted!\033[0m")
                    next()

                elif choice == "2":
                    my = [r for r in all_requests if r["username"] == orph_name]
                    if not my:
                        print("No requests made.")
                    else:
                        print(f"\n--- Your Pending Requests ({len(my)}) ---")
                        i = 1
                        for r in my:
                            print(f"{i}. Type: {r['type']} | Amount: Rs. {r['amount']}")
                            print(f"Statement: {r['statement']}")
                            print(f"Requested: {r['requested_at']}")
                            print("-" * 40)
                            i += 1
                    next()

                elif choice == "3":
                    my_fulfilled = [r for r in fulfilled_requests if r["username"] == orph_name]
                    if not my_fulfilled:
                        print("No fulfilled requests yet.")
                    else:
                        print(f"\n--- Your Fulfilled Requests ({len(my_fulfilled)}) ---")
                        total = 0
                        i = 1
                        for r in my_fulfilled:
                            amt = float(r['amount'])
                            total += amt
                            print(f"{i}. Type: {r['type']} | Amount: Rs. {amt}")
                            print(f"Statement: {r['statement']}")
                            print(f"Requested: {r['requested_at']}")
                            print(f"Fulfilled: {r.get('fulfilled_at', 'Unknown')}")
                            print("-" * 40)
                            i += 1
                        print(f"\n\033[92mTotal Received: Rs. {total}\033[0m")
                    next()

                elif choice == "4":
                    print("\033[92mLogged out successfully!\033[0m")
                    next()
                    break

                else:
                    print("\033[91mInvalid choice!\033[0m")
                    beep()
                    next()

# main menu

def main():
    os.system("cls")
    
    # Welcome screen with description
    print("\t\t\tIMPACT FUNDS")
    print("."*70)
    print("\n\tA Donation Management System for Orphanages")
    print("\nWelcome to Impact Funds! We are a non-profit NGO that aims \nto streamline interactions between donors, orphanages, and \nNGO workers, providing clear visibility into fund allocation \nand aid requests.")
    print("\nFeatures:")
    print("• Donors can securely donate to specific and general causes.")
    print("• Orphanages can request funds for urgent needs.") 
    print("• NGO workers can track funds, fulfill requests, and \n  visualize data for informed decisions.")
    print("• Real-time tracking of donations and requests.\n")
    print("."*70)
    next()
    
    os.system("cls")

    while True:
        os.system("cls")
        print("\n" + "."*50)
        print("\t\tMAIN MENU")
        print("."*50)
        print("1. NGO Worker Portal")
        print("2. Donor Portal") 
        print("3. Orphanage Portal")
        print("4. Exit System")
        print("."*50)
        
        choice = input("Enter your choice (1-4): ")
        
        if choice == "1":
            # Worker login
            os.system("cls")
            worker_portal()
                
        elif choice == "2":
            donor_signup_login()
            
        elif choice == "3":
            orphanage_signup_login()
            
        elif choice == "4":
            print("\nThank you for using IMPACT FUND!")
            print("Making a difference, one donation at a time.")
            exit()
            
        else:
            print("\033[91mInvalid choice! Please enter 1-4\033[0m")
            beep()
            os.system("cls")

if __name__ == "__main__":
    main()